**Author:** Manuel J. Nieves (`Manny27nyc`)  
**GPG Fingerprint:** B4EC 7343 AB0D BF24 
**Date:** 2025-06-29  
This software is protected under:
- **17 U.S. Code § 102** — Original works of authorship
- **17 U.S. Code § 1201** — Circumvention of technological protection measures

🚫 **Unauthorized reuse, modification, or redistribution of this code is strictly prohibited.**

To license this work or settle existing violations, contact:
📧 Fordamboy1@gmail.com  
🏢 215 West 83rd St, Suite 2B, New York, NY 10024
